
import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/app_button.dart';
import '../widgets/page_app_bar.dart';

class _DiaryItem {
  _DiaryItem(
      this.label,
      String text, {
        this.custom = false,
      }) : controller = TextEditingController(text: text);

  final String label;
  final TextEditingController controller;
  final bool custom;

  void dispose() => controller.dispose();
}

class DiaryScreen extends StatefulWidget {
  const DiaryScreen({super.key, this.onBack});

  final VoidCallback? onBack;

  @override
  State<DiaryScreen> createState() => _DiaryScreenState();
}

class _DiaryScreenState extends State<DiaryScreen> {
  static const Color _primary = Color(0xFF2F8877);
  static const Color _dark = Color(0xFF24313D);
  static const Color _muted = Color(0xFF7B8794);

  final List<_DiaryItem> _items = [
    _DiaryItem('Rhyme', 'Twinkle Twinkle Little Star'),
    _DiaryItem('Letter', 'A — Apple, Ant'),
    _DiaryItem('Number', 'Counting 1 to 5'),
    _DiaryItem('Colour', 'Red'),
    _DiaryItem('Activity', 'Colouring an apple'),
  ];

  final TextEditingController _homeNote = TextEditingController(
    text: 'Please practise the rhyme at home. '
        'Send a red-coloured object tomorrow.',
  );

  bool _isPreviewOpen = false;

  int get _filledCount => _items
      .where((item) => item.controller.text.trim().isNotEmpty)
      .length;

  int get _completion =>
      _items.isEmpty ? 0 : ((_filledCount / _items.length) * 100).round();

  bool get _published => AppState.instance.diaryPublished;

  @override
  void dispose() {
    for (final item in _items) {
      item.dispose();
    }
    _homeNote.dispose();
    super.dispose();
  }

  Future<void> _addItem() async {
    final label = await showDialog<String>(
      context: context,
      builder: (_) => const _AddItemDialog(),
    );

    if (!mounted || label == null || label.trim().isEmpty) return;

    setState(() {
      _items.add(
        _DiaryItem(label.trim(), '', custom: true),
      );
    });
  }

  void _removeItem(int index) {
    final item = _items.removeAt(index);

    setState(() {});

    Future<void>.delayed(
      const Duration(milliseconds: 250),
      item.dispose,
    );
  }

  void _publish() {
    if (_filledCount == 0) {
      _showMessage('Please write at least one diary item.');
      return;
    }

    AppState.instance.publishDiary();

    setState(() {});

    _showMessage(
      _published
          ? 'Diary updated successfully.'
          : 'Diary published successfully.',
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _showPreview() async {
    if (_filledCount == 0) {
      _showMessage('Add at least one activity to preview.');
      return;
    }

    setState(() => _isPreviewOpen = true);

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          child: Padding(
            padding: const EdgeInsets.all(19),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Diary Preview',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: _dark,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () =>
                            Navigator.pop(dialogContext),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    AppState.instance.className,
                    style: const TextStyle(
                      color: _primary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    AppState.dateLabel(DateTime.now()),
                    style: const TextStyle(
                      color: _muted,
                      fontSize: 11,
                    ),
                  ),
                  const Divider(height: 25),
                  const Text(
                    'TODAY WE LEARNED',
                    style: TextStyle(
                      color: _muted,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 12),
                  for (final item in _items)
                    if (item.controller.text.trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              Icons.check_circle_rounded,
                              size: 17,
                              color: _primary,
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.label,
                                    style: const TextStyle(
                                      color: _muted,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    item.controller.text.trim(),
                                    style: const TextStyle(
                                      color: _dark,
                                      fontSize: 12,
                                      height: 1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                  if (_homeNote.text.trim().isNotEmpty) ...[
                    const Divider(height: 22),
                    const Text(
                      'NOTE TO PARENTS',
                      style: TextStyle(
                        color: _muted,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _homeNote.text.trim(),
                      style: const TextStyle(
                        color: _dark,
                        fontSize: 12,
                        height: 1.6,
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () =>
                          Navigator.pop(dialogContext),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          vertical: 13,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Close Preview'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );

    if (mounted) {
      setState(() => _isPreviewOpen = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final published = _published;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F8F6),
      appBar: buildPageAppBar(
        title: 'Class Diary',
        subtitle:
        '${AppState.instance.className} · ${AppState.dateLabel(DateTime.now())}',
        onBack: widget.onBack,
        actions: [
          IconButton(
            tooltip: 'Preview diary',
            onPressed: _showPreview,
            icon: const Icon(
              Icons.visibility_outlined,
              color: _primary,
            ),
          ),
          const SizedBox(width: 5),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 13, 16, 20),
              children: [
                // HEADER CARD
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF2F8877),
                        Color(0xFF55AD96),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(21),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'A Day of Learning!',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Share today’s classroom activities '
                                  'with your students’ families.',
                              style: TextStyle(
                                color: Colors.white.withValues(
                                  alpha: 0.88,
                                ),
                                fontSize: 11,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(height: 13),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(
                                  alpha: 0.18,
                                ),
                                borderRadius:
                                BorderRadius.circular(20),
                              ),
                              child: Text(
                                published
                                    ? 'Diary published'
                                    : 'Draft diary',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        height: 68,
                        width: 68,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(
                            alpha: 0.17,
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(
                          Icons.menu_book_rounded,
                          color: Colors.white,
                          size: 37,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // COMPLETION CARD
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: _cardDecoration(),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Diary Completion',
                              style: TextStyle(
                                color: _dark,
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Text(
                            '$_completion%',
                            style: const TextStyle(
                              color: _primary,
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 11),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: _items.isEmpty
                              ? 0
                              : _filledCount / _items.length,
                          minHeight: 8,
                          backgroundColor:
                          const Color(0xFFEAF0ED),
                          valueColor:
                          const AlwaysStoppedAnimation<Color>(
                            _primary,
                          ),
                        ),
                      ),
                      const SizedBox(height: 9),
                      Row(
                        children: [
                          const Icon(
                            Icons.edit_note_rounded,
                            color: _muted,
                            size: 15,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '$_filledCount of ${_items.length} items completed',
                            style: const TextStyle(
                              color: _muted,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),

                // TAUGHT TODAY
                _sectionHeading(
                  'What We Learned Today',
                  'Add the topics and activities taught in class',
                  icon: Icons.auto_stories_rounded,
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: _cardDecoration(),
                  child: Column(
                    children: [
                      for (var i = 0; i < _items.length; i++)
                        _itemRow(i, _items[i]),

                      const SizedBox(height: 7),

                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _addItem,
                          icon: const Icon(
                            Icons.add_circle_outline_rounded,
                            size: 18,
                          ),
                          label: const Text('Add another activity'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _primary,
                            side: const BorderSide(
                              color: Color(0xFFB9DCD2),
                            ),
                            padding: const EdgeInsets.symmetric(
                              vertical: 12,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),

                // NOTE TO PARENTS
                _sectionHeading(
                  'Practice at Home',
                  'A message or reminder for parents',
                  icon: Icons.home_work_outlined,
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: _cardDecoration(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(
                            Icons.chat_bubble_outline_rounded,
                            size: 17,
                            color: _primary,
                          ),
                          SizedBox(width: 8),
                          Text(
                            'Note to Parents',
                            style: TextStyle(
                              color: _dark,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _homeNote,
                        maxLines: 4,
                        maxLength: 300,
                        textCapitalization:
                        TextCapitalization.sentences,
                        decoration: InputDecoration(
                          hintText:
                          'Write a note for parents...',
                          hintStyle: const TextStyle(
                            color: Color(0xFFA1AAA6),
                            fontSize: 11,
                          ),
                          filled: true,
                          fillColor: const Color(0xFFF7F9F8),
                          alignLabelWithHint: true,
                          contentPadding:
                          const EdgeInsets.all(13),
                          border: OutlineInputBorder(
                            borderRadius:
                            BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: AppColors.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius:
                            BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: AppColors.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius:
                            BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: _primary,
                              width: 1.4,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 17),

                // PUBLISH STATUS
                if (published)
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5EF),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: const Color(0xFFCBE7D9),
                      ),
                    ),
                    child: const Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.check_circle_rounded,
                          color: Color(0xFF278B65),
                          size: 19,
                        ),
                        SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Today’s diary is marked as published. '
                                'You can make changes and update it.',
                            style: TextStyle(
                              color: Color(0xFF267653),
                              fontSize: 11,
                              height: 1.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 10),
              ],
            ),
          ),

          // BOTTOM ACTIONS
          Container(
            padding: const EdgeInsets.fromLTRB(16, 11, 16, 13),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: SizedBox(
                      height: 48,
                      child: OutlinedButton.icon(
                        onPressed: _isPreviewOpen
                            ? null
                            : _showPreview,
                        icon: const Icon(
                          Icons.visibility_outlined,
                          size: 17,
                        ),
                        label: const Text(
                          'Preview',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _primary,
                          side: const BorderSide(
                            color: Color(0xFFB9DCD2),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: AppButton(
                      title: published
                          ? 'Update Diary'
                          : 'Publish Diary',
                      icon: published
                          ? Icons.refresh_rounded
                          : Icons.send_rounded,
                      onPressed: _publish,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeading(
      String title,
      String subtitle, {
        required IconData icon,
      }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 37,
          width: 37,
          decoration: BoxDecoration(
            color: const Color(0xFFE3F2ED),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(
            icon,
            color: _primary,
            size: 19,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: _dark,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: const TextStyle(
                  color: _muted,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _itemRow(int index, _DiaryItem item) {
    final hasText = item.controller.text.trim().isNotEmpty;

    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.fromLTRB(11, 7, 5, 7),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F9F8),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: const Color(0xFFEDF1EF),
        ),
      ),
      child: Row(
        children: [
          Container(
            height: 35,
            width: 35,
            decoration: BoxDecoration(
              color: hasText
                  ? const Color(0xFFE3F2ED)
                  : const Color(0xFFFFF0D9),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              _iconFor(item.label),
              size: 18,
              color: hasText
                  ? _primary
                  : const Color(0xFFD99A39),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        item.label,
                        style: const TextStyle(
                          color: _dark,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    if (hasText)
                      const Icon(
                        Icons.check_circle_rounded,
                        color: _primary,
                        size: 14,
                      ),
                  ],
                ),
                TextField(
                  controller: item.controller,
                  onChanged: (_) => setState(() {}),
                  textCapitalization:
                  TextCapitalization.sentences,
                  style: const TextStyle(
                    color: _dark,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: const InputDecoration(
                    hintText: 'Tap to write...',
                    hintStyle: TextStyle(
                      color: Color(0xFFA1AAA6),
                      fontSize: 10,
                      fontWeight: FontWeight.w400,
                    ),
                    isDense: true,
                    filled: false,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding: EdgeInsets.only(
                      top: 5,
                      bottom: 4,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (item.custom)
            IconButton(
              tooltip: 'Remove item',
              visualDensity: VisualDensity.compact,
              onPressed: () => _removeItem(index),
              icon: const Icon(
                Icons.delete_outline_rounded,
                size: 18,
                color: Color(0xFFD47A70),
              ),
            ),
        ],
      ),
    );
  }

  IconData _iconFor(String label) {
    switch (label.toLowerCase()) {
      case 'rhyme':
        return Icons.music_note_rounded;
      case 'letter':
        return Icons.abc_rounded;
      case 'number':
        return Icons.calculate_outlined;
      case 'colour':
      case 'color':
        return Icons.palette_outlined;
      case 'activity':
        return Icons.brush_rounded;
      case 'story':
        return Icons.menu_book_rounded;
      case 'game':
        return Icons.sports_esports_outlined;
      case 'shape':
        return Icons.category_outlined;
      default:
        return Icons.edit_note_rounded;
    }
  }

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(17),
      border: Border.all(
        color: const Color(0xFFE8EEEB),
      ),
      boxShadow: [
        BoxShadow(
          color: _dark.withValues(alpha: 0.025),
          blurRadius: 12,
          offset: const Offset(0, 4),
        ),
      ],
    );
  }
}

class _AddItemDialog extends StatefulWidget {
  const _AddItemDialog();

  @override
  State<_AddItemDialog> createState() => _AddItemDialogState();
}

class _AddItemDialogState extends State<_AddItemDialog> {
  final TextEditingController _label = TextEditingController();

  @override
  void dispose() {
    _label.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      title: const Text(
        'Add Diary Item',
        style: TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w800,
        ),
      ),
      content: TextField(
        controller: _label,
        autofocus: true,
        textCapitalization: TextCapitalization.words,
        maxLength: 30,
        decoration: const InputDecoration(
          hintText: 'e.g. Story, Game, Shape',
          prefixIcon: Icon(Icons.edit_note_rounded),
        ),
        onSubmitted: (value) {
          if (value.trim().isNotEmpty) {
            Navigator.pop(context, value.trim());
          }
        },
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_label.text.trim().isNotEmpty) {
              Navigator.pop(context, _label.text.trim());
            }
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF2F8877),
            foregroundColor: Colors.white,
          ),
          child: const Text('Add Item'),
        ),
      ],
    );
  }
}
