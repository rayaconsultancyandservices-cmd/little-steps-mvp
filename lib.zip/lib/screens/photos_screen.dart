
import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/app_button.dart';
import '../widgets/page_app_bar.dart';

class _Photo {
  _Photo(this.colorIndex, [Set<String>? tags])
      : tags = tags ?? <String>{};

  final int colorIndex;
  final Set<String> tags;
}

class PhotosScreen extends StatefulWidget {
  const PhotosScreen({super.key, this.onBack});

  final VoidCallback? onBack;

  @override
  State<PhotosScreen> createState() => _PhotosScreenState();
}

class _PhotosScreenState extends State<PhotosScreen> {
  static const Color _primary = Color(0xFF2F8877);
  static const Color _dark = Color(0xFF24313D);
  static const Color _muted = Color(0xFF7B8794);

  static const List<Color> _tileBg = [
    Color(0xFFFFE3DC),
    Color(0xFFFFEBCF),
    Color(0xFFDCEBFF),
    Color(0xFFD9F1E8),
    Color(0xFFE6E0FA),
    Color(0xFFFFDDE0),
  ];

  static const List<Color> _tileFg = [
    Color(0xFFE8765B),
    Color(0xFFE59A2E),
    Color(0xFF4A8EE8),
    Color(0xFF2E9E7B),
    Color(0xFF7C5CE6),
    Color(0xFFE0535F),
  ];

  static const List<IconData> _photoIcons = [
    Icons.palette_rounded,
    Icons.toys_rounded,
    Icons.menu_book_rounded,
    Icons.music_note_rounded,
    Icons.sports_soccer_rounded,
    Icons.celebration_rounded,
  ];

  static const List<String> _children = [
    'Aarav',
    'Diya',
    'Kabir',
    'Saanvi',
    'Vihaan',
    'Anaya',
    'Vivaan',
    'Advik',
  ];

  final TextEditingController _caption = TextEditingController();

  int _mode = 0;
  int _counter = 6;

  final List<_Photo> _photos = [
    _Photo(0, {'Aarav'}),
    _Photo(1, {'Aarav', 'Diya'}),
    _Photo(2, {'Aarav', 'Saanvi'}),
    _Photo(3, {'Diya'}),
    _Photo(4, {'Saanvi'}),
    _Photo(5),
  ];

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  void _msg(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  void _addPhoto(String source) {
    final tagged = _children[_counter % _children.length];

    setState(() {
      _photos.add(
        _Photo(_counter % _tileBg.length, {tagged}),
      );
      _counter++;
    });

    _msg('$source demo photo added. Suggested tag: $tagged');
  }

  void _removePhoto(int index) {
    setState(() => _photos.removeAt(index));
  }

  Map<String, int> get _tagCounts {
    final map = <String, int>{};

    for (final child in _children) {
      final count = _photos
          .where((photo) => photo.tags.contains(child))
          .length;

      if (count > 0) {
        map[child] = count;
      }
    }

    return map;
  }

  int get _untaggedCount =>
      _photos.where((photo) => photo.tags.isEmpty).length;

  void _editTags(_Photo photo) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            return Container(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 38,
                        height: 4,
                        decoration: BoxDecoration(
                          color: const Color(0xFFDCE4DF),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Who is in this photo?',
                      style: TextStyle(
                        color: _dark,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Select all children visible in this photo.',
                      style: TextStyle(
                        color: _muted,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 17),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final child in _children)
                          FilterChip(
                            label: Text(child),
                            selected: photo.tags.contains(child),
                            selectedColor: AppColors.primaryLight,
                            checkmarkColor: _primary,
                            onSelected: (selected) {
                              setSheet(() {
                                if (selected) {
                                  photo.tags.add(child);
                                } else {
                                  photo.tags.remove(child);
                                }
                              });
                              setState(() {});
                            },
                          ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    AppButton(
                      title: 'Save Photo Tags',
                      icon: Icons.check_circle_outline_rounded,
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _send() {
    if (_photos.isEmpty) return;

    if (_mode == 0 && _untaggedCount > 0) {
      _msg(
        '$_untaggedCount photo(s) have no child tagged. '
            'Please tag them before sending.',
      );
      return;
    }

    final count = _photos.length;
    final target = _mode == 0
        ? 'parents of tagged children'
        : 'all ${AppState.instance.totalChildren} children';

    AppState.instance.addPhotos(count);

    setState(() {
      _photos.clear();
      _caption.clear();
    });

    _msg('$count photo(s) shared with $target.');
  }

  void _confirmRemove(int index) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        title: const Text(
          'Remove photo?',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'This photo will be removed from the current selection.',
          style: TextStyle(fontSize: 12),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _removePhoto(index);
            },
            child: const Text(
              'Remove',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final counts = _tagCounts;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F8F6),
      appBar: buildPageAppBar(
        title: 'Photos',
        subtitle: '${AppState.instance.className} · Today',
        onBack: widget.onBack,
        actions: [
          IconButton(
            tooltip: 'Photo information',
            onPressed: _showInfo,
            icon: const Icon(
              Icons.info_outline_rounded,
              color: _primary,
            ),
          ),
          const SizedBox(width: 5),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
              children: [
                // HEADER
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF2F8877),
                        Color(0xFF55AD96),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Capture Little Moments!',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Share classroom activities and '
                                  'special memories with parents.',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.9),
                                fontSize: 10,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.18),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                '${_photos.length} photos selected',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(
                          Icons.photo_camera_back_rounded,
                          color: Colors.white,
                          size: 34,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // MODE
                const Text(
                  'Who should receive these photos?',
                  style: TextStyle(
                    color: _dark,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),

                Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFE5ECE9),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _modeButton(
                          title: 'Selected Children',
                          subtitle: 'Tagged parents only',
                          icon: Icons.person_pin_circle_outlined,
                          value: 0,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: _modeButton(
                          title: 'Whole Class',
                          subtitle: 'All families',
                          icon: Icons.groups_2_outlined,
                          value: 1,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 17),

                // CAMERA AND GALLERY
                Row(
                  children: [
                    Expanded(
                      child: _sourceButton(
                        title: 'Camera',
                        subtitle: 'Take a photo',
                        icon: Icons.camera_alt_rounded,
                        onTap: () => _addPhoto('Camera'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _sourceButton(
                        title: 'Gallery',
                        subtitle: 'Choose photos',
                        icon: Icons.photo_library_rounded,
                        onTap: () => _addPhoto('Gallery'),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // PHOTO GRID HEADER
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Selected Photos',
                        style: TextStyle(
                          color: _dark,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Text(
                      '${_photos.length} items',
                      style: const TextStyle(
                        color: _muted,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                if (_photos.isEmpty)
                  _emptyPhotos()
                else
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _photos.length,
                    gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 9,
                      mainAxisSpacing: 9,
                      childAspectRatio: 0.91,
                    ),
                    itemBuilder: (context, index) {
                      final photo = _photos[index];
                      final noTag =
                          _mode == 0 && photo.tags.isEmpty;

                      return _photoTile(photo, index, noTag);
                    },
                  ),

                const SizedBox(height: 18),

                // TAGGED CHILDREN
                if (_mode == 0) ...[
                  _taggedChildrenCard(counts),
                  const SizedBox(height: 16),
                ] else
                  _wholeClassCard(),

                const SizedBox(height: 16),

                // CAPTION
                const Text(
                  'Photo Caption',
                  style: TextStyle(
                    color: _dark,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 7),
                TextField(
                  controller: _caption,
                  maxLines: 3,
                  minLines: 2,
                  maxLength: 150,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    hintText:
                    'e.g. Rhyme time and colouring with crayons...',
                    hintStyle: const TextStyle(
                      color: Color(0xFFA1AAA6),
                      fontSize: 11,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: Color(0xFFE5ECE9),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: Color(0xFFE5ECE9),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: _primary,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // BOTTOM SEND BAR
          Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(
                  color: Color(0xFFE7EEEA),
                ),
              ),
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_mode == 0 && _untaggedCount > 0)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.warning_amber_rounded,
                            color: Color(0xFFD9822B),
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              '$_untaggedCount photo(s) need child tags.',
                              style: const TextStyle(
                                color: Color(0xFFD9822B),
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  AppButton(
                    title: 'Send ${_photos.length} Photos',
                    icon: Icons.send_rounded,
                    onPressed: _photos.isEmpty ? null : _send,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _modeButton({
    required String title,
    required String subtitle,
    required IconData icon,
    required int value,
  }) {
    final selected = _mode == value;

    return InkWell(
      borderRadius: BorderRadius.circular(11),
      onTap: () => setState(() => _mode = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(
          vertical: 12,
          horizontal: 7,
        ),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFFEAF5F0)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(11),
          border: Border.all(
            color: selected
                ? _primary
                : Colors.transparent,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: selected ? _primary : _muted,
              size: 22,
            ),
            const SizedBox(height: 6),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: selected ? _primary : _dark,
                fontSize: 10,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _muted,
                fontSize: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sourceButton({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 10,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: const Color(0xFFDCE9E3),
          ),
        ),
        child: Row(
          children: [
            Container(
              height: 39,
              width: 39,
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: _primary,
                size: 20,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: _dark,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: _muted,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _photoTile(_Photo photo, int index, bool noTag) {
    final colorIndex = photo.colorIndex % _tileBg.length;

    return InkWell(
      onTap: _mode == 0 ? () => _editTags(photo) : null,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        decoration: BoxDecoration(
          color: _tileBg[colorIndex],
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: noTag
                ? const Color(0xFFD9822B)
                : Colors.white,
            width: noTag ? 1.7 : 1,
          ),
        ),
        child: Stack(
          children: [
            Center(
              child: Icon(
                _photoIcons[colorIndex],
                color: _tileFg[colorIndex],
                size: 34,
              ),
            ),
            Positioned(
              top: 5,
              right: 5,
              child: InkWell(
                onTap: () => _confirmRemove(index),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 24,
                  width: 24,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.close_rounded,
                    size: 15,
                    color: _dark,
                  ),
                ),
              ),
            ),
            if (_mode == 0)
              Positioned(
                left: 5,
                right: 5,
                bottom: 5,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.94),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    noTag ? 'Tap to tag' : photo.tags.join(', '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: noTag
                          ? const Color(0xFFD9822B)
                          : _dark,
                      fontSize: 8,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _taggedChildrenCard(Map<String, int> counts) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFE5ECE9),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Tagged Children',
                  style: TextStyle(
                    color: _dark,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFEDE7FF),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '✦ Auto-tag demo',
                  style: TextStyle(
                    color: Color(0xFF6C4DD9),
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (counts.isEmpty)
            const Text(
              'No child tagged yet.',
              style: TextStyle(
                color: _muted,
                fontSize: 11,
              ),
            )
          else
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (final entry in counts.entries)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Text(
                      '${entry.key} · ${entry.value} photos',
                      style: const TextStyle(
                        color: _primary,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),
          const SizedBox(height: 12),
          const Text(
            'Parents receive photos tagged with their child. '
                'Please verify the suggested tags before sharing.',
            style: TextStyle(
              color: _muted,
              fontSize: 10,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _wholeClassCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF2FC),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: const Color(0xFFD9E7F8),
        ),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.groups_rounded,
            color: Color(0xFF3979B7),
            size: 25,
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              'These photos will be shared with all '
                  '${AppState.instance.totalChildren} children '
                  'of ${AppState.instance.className}.',
              style: const TextStyle(
                color: Color(0xFF326A9E),
                fontSize: 10,
                height: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyPhotos() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 30),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: const Color(0xFFE5ECE9),
        ),
      ),
      child: const Column(
        children: [
          Icon(
            Icons.photo_library_outlined,
            color: Color(0xFF9BAAA4),
            size: 40,
          ),
          SizedBox(height: 10),
          Text(
            'No photos selected',
            style: TextStyle(
              color: _dark,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 5),
          Text(
            'Use Camera or Gallery to add photos.',
            style: TextStyle(
              color: _muted,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }

  void _showInfo() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        title: const Text(
          'Photo Sharing',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'Choose Selected Children to share photos only '
              'with parents of tagged children. Choose Whole Class '
              'to share with all families. Verify photo tags before sending.',
          style: TextStyle(
            fontSize: 12,
            height: 1.6,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
