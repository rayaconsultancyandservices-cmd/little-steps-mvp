
import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/app_button.dart';
import '../widgets/page_app_bar.dart';

class _Student {
  _Student(this.name);

  final String name;
  String? status;
  int? aiConfidence;
  bool aiUnsure = false;
  bool notSeen = false;
}

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key, this.onBack});

  final VoidCallback? onBack;

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  static const Color green = Color(0xFF269B73);
  static const Color red = Color(0xFFE36B61);
  static const Color orange = Color(0xFFD99437);
  static const Color purple = Color(0xFF7963C9);
  static const Color dark = Color(0xFF183B45);
  static const Color primary = Color(0xFF168C80);

  final TextEditingController searchController =
  TextEditingController();

  final List<_Student> students = <String>[
    'Aarav Mehta',
    'Diya Iyer',
    'Kabir Sharma',
    'Saanvi Rao',
    'Vihaan Joshi',
    'Anaya Patil',
    'Vivaan Deshmukh',
    'Advik Shah',
    'Ira Kulkarni',
    'Reyansh More',
    'Myra Pawar',
    'Arjun Singh',
    'Aadhya Kale',
    'Kiara Mehta',
    'Rudra Jadhav',
    'Pari Gupta',
    'Atharv Shinde',
    'Sara Khan',
    'Omkar Pawar',
    'Ishaan More',
    'Riya Patil',
    'Vedant Joshi',
  ].map(_Student.new).toList();

  int selectedFilter = 0;
  bool aiScanned = false;
  bool isScanning = false;
  bool isSaving = false;
  String searchQuery = '';

  int get present =>
      students.where((s) => s.status == 'P').length;

  int get absent =>
      students.where((s) => s.status == 'A').length;

  int get notMarked =>
      students.where((s) => s.status == null).length;

  int get total => students.length;

  double get percentage =>
      total == 0 ? 0 : present / total * 100;

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  void markStudent(_Student student, String status) {
    setState(() {
      student.status = status;
      student.aiUnsure = false;
      student.notSeen = false;
    });
  }

  void markAllPresent() {
    setState(() {
      for (final student in students) {
        student.status = 'P';
        student.aiUnsure = false;
        student.notSeen = false;
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('All students marked Present.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void clearAttendance() {
    setState(() {
      for (final student in students) {
        student.status = null;
        student.aiConfidence = null;
        student.aiUnsure = false;
        student.notSeen = false;
      }
      aiScanned = false;
    });
  }

  // AI CAMERA DEMO
  Future<void> scanWithCamera() async {
    if (isScanning) return;

    setState(() => isScanning = true);

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 55,
              width: 55,
              child: CircularProgressIndicator(
                color: primary,
                strokeWidth: 4,
              ),
            ),
            SizedBox(height: 18),
            Text(
              'Scanning Classroom...',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: dark,
              ),
            ),
            SizedBox(height: 7),
            Text(
              'AI attendance demo is processing.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11),
            ),
          ],
        ),
      ),
    );

    await Future<void>.delayed(
      const Duration(seconds: 2),
    );

    if (!mounted) return;

    Navigator.of(context).pop();

    const unsure = {2, 9};
    const notSeen = {4, 15};

    setState(() {
      isScanning = false;
      aiScanned = true;

      for (int i = 0; i < students.length; i++) {
        final student = students[i];

        student.aiUnsure = false;
        student.notSeen = false;

        if (unsure.contains(i)) {
          student.status = null;
          student.aiConfidence = 62;
          student.aiUnsure = true;
        } else if (notSeen.contains(i)) {
          student.status = null;
          student.aiConfidence = null;
          student.notSeen = true;
        } else {
          student.status = 'P';
          student.aiConfidence = 90 + (i * 3) % 10;
        }
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Demo scan completed. $present students marked present. Please verify.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // SAVE ATTENDANCE
  Future<void> saveAttendance() async {
    if (isSaving) return;

    if (notMarked > 0) {
      final result = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text(
            'Incomplete Attendance',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          content: Text(
            '$notMarked students are still not marked. '
                'Would you like to mark them Absent and continue?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Review'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: primary,
                foregroundColor: Colors.white,
              ),
              child: const Text('Mark Absent'),
            ),
          ],
        ),
      );

      if (result != true || !mounted) return;

      setState(() {
        for (final student in students) {
          if (student.status == null) {
            student.status = 'A';
            student.aiUnsure = false;
            student.notSeen = false;
          }
        }
      });
    }

    setState(() => isSaving = true);

    await Future<void>.delayed(
      const Duration(milliseconds: 400),
    );

    if (!mounted) return;

    AppState.instance.saveAttendance(
      present: present,
      absent: absent,
    );

    setState(() => isSaving = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Attendance saved: $present Present, $absent Absent.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  List<_Student> get visibleStudents {
    return students.where((student) {
      final matchesSearch = student.name
          .toLowerCase()
          .contains(searchQuery.toLowerCase());

      bool matchesFilter;

      switch (selectedFilter) {
        case 1:
          matchesFilter = student.status == 'P';
          break;
        case 2:
          matchesFilter = student.status == 'A';
          break;
        case 3:
          matchesFilter = student.status == null;
          break;
        default:
          matchesFilter = true;
      }

      return matchesSearch && matchesFilter;
    }).toList();
  }

  String initials(String name) {
    return name
        .split(' ')
        .map((word) => word[0])
        .take(2)
        .join();
  }

  @override
  Widget build(BuildContext context) {
    final list = visibleStudents;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F7),
      appBar: buildPageAppBar(
        title: 'Attendance',
        subtitle:
        '${AppState.instance.className} · ${AppState.dateLabel(DateTime.now())}',
        onBack: widget.onBack,
        actions: [
          IconButton(
            tooltip: 'Reset attendance',
            onPressed: clearAttendance,
            icon: const Icon(
              Icons.refresh_rounded,
              color: primary,
            ),
          ),
          const SizedBox(width: 5),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(17, 12, 17, 15),
              children: [
                // CLASS HEADER
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF168C80),
                        Color(0xFF39B5A1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(21),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Class Attendance',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 7),
                            Text(
                              AppState.instance.className,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 23,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$total Students • ${AppState.dateLabel(DateTime.now())}',
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: 61,
                        width: 61,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(
                          Icons.fact_check_rounded,
                          color: Colors.white,
                          size: 34,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 19),

                // SUMMARY
                Row(
                  children: [
                    Expanded(
                      child: _summaryCard(
                        'Present',
                        present,
                        green,
                        const Color(0xFFE5F5ED),
                        Icons.check_circle_rounded,
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: _summaryCard(
                        'Absent',
                        absent,
                        red,
                        const Color(0xFFFFEFED),
                        Icons.cancel_rounded,
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: _summaryCard(
                        'Pending',
                        notMarked,
                        orange,
                        const Color(0xFFFFF4E4),
                        Icons.pending_actions_rounded,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 17),

                // ATTENDANCE PROGRESS
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: _cardDecoration(),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Attendance Progress',
                              style: TextStyle(
                                color: dark,
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Text(
                            '${percentage.toStringAsFixed(0)}%',
                            style: const TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                              color: primary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: LinearProgressIndicator(
                          value: present / total,
                          minHeight: 9,
                          backgroundColor:
                          const Color(0xFFEAF0ED),
                          valueColor:
                          const AlwaysStoppedAnimation<Color>(
                            primary,
                          ),
                        ),
                      ),
                      const SizedBox(height: 9),
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Present students / Total students',
                              style: TextStyle(
                                fontSize: 10,
                                color: Color(0xFF84918D),
                              ),
                            ),
                          ),
                          Text(
                            '$present / $total',
                            style: const TextStyle(
                              fontSize: 11,
                              color: dark,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 19),

                // AI SCAN
                Material(
                  color: const Color(0xFFF0ECFF),
                  borderRadius: BorderRadius.circular(18),
                  child: InkWell(
                    onTap: scanWithCamera,
                    borderRadius: BorderRadius.circular(18),
                    child: Padding(
                      padding: const EdgeInsets.all(15),
                      child: Row(
                        children: [
                          Container(
                            height: 48,
                            width: 48,
                            decoration: BoxDecoration(
                              color: purple,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(
                              Icons.center_focus_strong_rounded,
                              color: Colors.white,
                              size: 25,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Text(
                                  aiScanned
                                      ? 'Scan Again'
                                      : 'AI Classroom Scan',
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    color: dark,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                const Text(
                                  'Demo feature: review AI attendance before saving.',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Color(0xFF77708F),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: purple,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 23),

                // STUDENT LIST TITLE
                Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Student List',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: dark,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Mark each student’s attendance',
                            style: TextStyle(
                              fontSize: 11,
                              color: Color(0xFF84918D),
                            ),
                          ),
                        ],
                      ),
                    ),
                    TextButton.icon(
                      onPressed: markAllPresent,
                      icon: const Icon(
                        Icons.done_all_rounded,
                        size: 16,
                      ),
                      label: const Text(
                        'All Present',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        foregroundColor: primary,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 13),

                // SEARCH
                TextField(
                  controller: searchController,
                  onChanged: (value) {
                    setState(() => searchQuery = value);
                  },
                  decoration: InputDecoration(
                    hintText: 'Search student by name...',
                    hintStyle: const TextStyle(
                      color: Color(0xFFA1ADA8),
                      fontSize: 12,
                    ),
                    prefixIcon: const Icon(
                      Icons.search_rounded,
                      color: primary,
                    ),
                    suffixIcon: searchQuery.isNotEmpty
                        ? IconButton(
                      onPressed: () {
                        searchController.clear();
                        setState(() => searchQuery = '');
                      },
                      icon: const Icon(Icons.close_rounded),
                    )
                        : null,
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 14,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: Color(0xFFE5ECE9),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: Color(0xFFE5ECE9),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(
                        color: primary,
                        width: 1.4,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 13),

                // FILTER CHIPS
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _filterChip('All', 0, total),
                      _filterChip('Present', 1, present),
                      _filterChip('Absent', 2, absent),
                      _filterChip('Pending', 3, notMarked),
                    ],
                  ),
                ),

                const SizedBox(height: 13),

                // STUDENT LIST CARD
                Container(
                  decoration: _cardDecoration(),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 13,
                        ),
                        decoration: const BoxDecoration(
                          color: Color(0xFFF8FAF9),
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(17),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'STUDENT DETAILS',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF84918D),
                                  letterSpacing: 0.7,
                                ),
                              ),
                            ),
                            Text(
                              '${list.length} students',
                              style: const TextStyle(
                                fontSize: 10,
                                color: primary,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),

                      if (list.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(28),
                          child: Column(
                            children: [
                              Icon(
                                Icons.search_off_rounded,
                                color: Color(0xFFADB8B4),
                                size: 35,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'No students found',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: dark,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Try another name or filter.',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Color(0xFF84918D),
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        ...List.generate(list.length, (index) {
                          final student = list[index];

                          return Column(
                            children: [
                              _studentRow(student),
                              if (index != list.length - 1)
                                const Divider(
                                  height: 1,
                                  indent: 15,
                                  endIndent: 15,
                                  color: Color(0xFFEDF1EF),
                                ),
                            ],
                          );
                        }),
                    ],
                  ),
                ),

                const SizedBox(height: 15),

                // LEGEND
                Container(
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF4F1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.info_outline_rounded,
                        color: primary,
                        size: 17,
                      ),
                      SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          'P = Present   •   A = Absent   •   Grey = Not marked',
                          style: TextStyle(
                            color: dark,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // BOTTOM SAVE BUTTON
          Container(
            padding: const EdgeInsets.fromLTRB(17, 11, 17, 13),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: AppButton(
                title: isSaving
                    ? 'Saving Attendance...'
                    : 'Save Attendance',
                icon: Icons.check_circle_rounded,
                onPressed: isSaving ? null : saveAttendance,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // SUMMARY CARD
  Widget _summaryCard(
      String title,
      int count,
      Color color,
      Color background,
      IconData icon,
      ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 21),
          const SizedBox(height: 8),
          Text(
            '$count',
            style: TextStyle(
              color: color,
              fontSize: 23,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              color: Color(0xFF84918D),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // FILTER CHIP
  Widget _filterChip(String label, int index, int count) {
    final selected = selectedFilter == index;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        selected: selected,
        showCheckmark: false,
        onSelected: (_) {
          setState(() => selectedFilter = index);
        },
        backgroundColor: Colors.white,
        selectedColor: primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: selected
                ? primary
                : const Color(0xFFE5ECE9),
          ),
        ),
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : dark,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '$count',
              style: TextStyle(
                color: selected
                    ? Colors.white70
                    : const Color(0xFF84918D),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // STUDENT ROW
  Widget _studentRow(_Student student) {
    final isPresent = student.status == 'P';
    final isAbsent = student.status == 'A';

    String subtitle = 'Attendance not marked';
    Color subtitleColor = const Color(0xFF98A49F);

    if (isPresent) {
      subtitle = student.aiConfidence != null
          ? 'AI Demo confidence: ${student.aiConfidence}%'
          : 'Marked Present';
      subtitleColor = green;
    } else if (isAbsent) {
      subtitle = 'Marked Absent';
      subtitleColor = red;
    } else if (student.aiUnsure) {
      subtitle = 'AI unsure — please verify';
      subtitleColor = orange;
    } else if (student.notSeen) {
      subtitle = 'Not detected in demo scan';
      subtitleColor = orange;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 13,
        vertical: 11,
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 21,
            backgroundColor: const Color(0xFFE4F3EF),
            child: Text(
              initials(student.name),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: primary,
              ),
            ),
          ),
          const SizedBox(width: 11),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  student.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: dark,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 9,
                    color: subtitleColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 7),

          _statusButton(
            'P',
            isPresent,
            green,
                () => markStudent(student, 'P'),
          ),

          const SizedBox(width: 7),

          _statusButton(
            'A',
            isAbsent,
            red,
                () => markStudent(student, 'A'),
          ),
        ],
      ),
    );
  }

  // PRESENT / ABSENT BUTTON
  Widget _statusButton(
      String label,
      bool selected,
      Color color,
      VoidCallback onTap,
      ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 35,
        width: 35,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? color : const Color(0xFFF3F6F5),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? color : const Color(0xFFE5ECE9),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : const Color(0xFF84918D),
            fontWeight: FontWeight.w800,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  // COMMON CARD DECORATION
  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(
        color: const Color(0xFFE8EEEB),
      ),
      boxShadow: [
        BoxShadow(
          color: dark.withOpacity(0.025),
          blurRadius: 14,
          offset: const Offset(0, 4),
        ),
      ],
    );
  }
}
