
import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/app_button.dart';
import '../widgets/page_app_bar.dart';

class CircularScreen extends StatefulWidget {
  const CircularScreen({super.key, this.onBack});

  final VoidCallback? onBack;

  @override
  State<CircularScreen> createState() => _CircularScreenState();
}

class _CircularScreenState extends State<CircularScreen> {
  static const Color _primary = Color(0xFF2F8877);
  static const Color _dark = Color(0xFF24313D);
  static const Color _muted = Color(0xFF7B8794);

  static const Map<String, int> _classFamilies = {
    'Nursery A': 22,
    'Nursery B': 21,
    'LKG': 22,
    'UKG': 21,
  };

  static const List<String> _categories = [
    'Notice',
    'Holiday',
    'Meeting',
    'Event',
    'Celebration',
  ];

  static const Map<String, IconData> _categoryIcons = {
    'Notice': Icons.campaign_rounded,
    'Holiday': Icons.beach_access_rounded,
    'Meeting': Icons.groups_rounded,
    'Event': Icons.event_rounded,
    'Celebration': Icons.celebration_rounded,
  };

  static const Map<String, Color> _categoryColors = {
    'Notice': Color(0xFF4786C7),
    'Holiday': Color(0xFFE39A3A),
    'Meeting': Color(0xFF8066C8),
    'Event': Color(0xFF2F8877),
    'Celebration': Color(0xFFE47778),
  };

  int _audience = 0;
  final Set<String> _chosen = {};

  String _category = 'Notice';
  DateTime? _eventDate;
  String? _attachment;

  final TextEditingController _title = TextEditingController();
  final TextEditingController _message = TextEditingController();

  bool _isSending = false;

  int get _families {
    switch (_audience) {
      case 0:
        return AppState.instance.totalFamilies;
      case 1:
        return _classFamilies['Nursery A']!;
      default:
        return _chosen.fold<int>(
          0,
              (sum, name) => sum + (_classFamilies[name] ?? 0),
        );
    }
  }

  String get _audienceLabel {
    switch (_audience) {
      case 0:
        return 'Whole school';
      case 1:
        return 'Nursery A';
      default:
        return _chosen.join(', ');
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _message.dispose();
    super.dispose();
  }

  void _showMessage(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _pickClasses() async {
    final temp = Set<String>.of(_chosen);

    final result = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            return Container(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(25),
                ),
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        height: 4,
                        width: 42,
                        decoration: BoxDecoration(
                          color: const Color(0xFFDDE5E1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    const SizedBox(height: 19),
                    const Text(
                      'Choose Classes',
                      style: TextStyle(
                        color: _dark,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Select one or more classes to receive this circular.',
                      style: TextStyle(
                        color: _muted,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 14),
                    for (final entry in _classFamilies.entries)
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: temp.contains(entry.key),
                        activeColor: _primary,
                        title: Text(
                          entry.key,
                          style: const TextStyle(
                            color: _dark,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        subtitle: Text(
                          '${entry.value} families',
                          style: const TextStyle(
                            color: _muted,
                            fontSize: 10,
                          ),
                        ),
                        onChanged: (value) {
                          setSheet(() {
                            if (value == true) {
                              temp.add(entry.key);
                            } else {
                              temp.remove(entry.key);
                            }
                          });
                        },
                      ),
                    const SizedBox(height: 10),
                    AppButton(
                      title: temp.isEmpty
                          ? 'Choose at least one class'
                          : 'Done · ${temp.length} selected',
                      icon: Icons.check_rounded,
                      onPressed: temp.isEmpty
                          ? null
                          : () => Navigator.pop(ctx, temp),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (!mounted || result == null) return;

    setState(() {
      _chosen
        ..clear()
        ..addAll(result);
      _audience = 2;
    });
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final picked = await showDatePicker(
      context: context,
      initialDate: _eventDate ?? today,
      firstDate: today,
      lastDate: today.add(const Duration(days: 365)),
      helpText: 'Select circular date',
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _primary,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: _dark,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && mounted) {
      setState(() => _eventDate = picked);
    }
  }

  // Original file picker was a demo. This keeps that behavior.
  void _attach() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 15, 16, 20),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(23),
            ),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Add Attachment',
                  style: TextStyle(
                    color: _dark,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: _attachmentIcon(
                    Icons.picture_as_pdf_rounded,
                    const Color(0xFFE16B61),
                  ),
                  title: const Text('Attach PDF'),
                  subtitle: const Text('PDF document · Demo'),
                  onTap: () {
                    Navigator.pop(ctx);
                    setState(() => _attachment = 'circular.pdf');
                  },
                ),
                ListTile(
                  leading: _attachmentIcon(
                    Icons.image_rounded,
                    const Color(0xFF4786C7),
                  ),
                  title: const Text('Attach Image'),
                  subtitle: const Text('Image file · Demo'),
                  onTap: () {
                    Navigator.pop(ctx);
                    setState(() => _attachment = 'notice.jpg');
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _attachmentIcon(IconData icon, Color color) {
    return Container(
      height: 42,
      width: 42,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: color),
    );
  }

  String _validationError() {
    if (_title.text.trim().isEmpty) {
      return 'Please enter a circular title.';
    }

    if (_message.text.trim().isEmpty) {
      return 'Please enter the circular message.';
    }

    if (_audience == 2 && _chosen.isEmpty) {
      return 'Please choose at least one class.';
    }

    if (_category != 'Notice' && _eventDate == null) {
      return 'Please select the date for this $_category.';
    }

    return '';
  }

  Future<void> _send() async {
    if (_isSending) return;

    final error = _validationError();

    if (error.isNotEmpty) {
      _showMessage(error);
      return;
    }

    final families = _families;
    final title = _title.text.trim();
    final category = _category;
    final audience = _audienceLabel;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(21),
          ),
          title: const Text(
            'Confirm Circular',
            style: TextStyle(
              color: _dark,
              fontSize: 17,
              fontWeight: FontWeight.w800,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: _dark,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Category: $category\n'
                    'Audience: $audience\n'
                    'Families: $families'
                    '${_eventDate == null ? '' : '\nDate: ${AppState.shortDate(_eventDate!)}'}',
                style: const TextStyle(
                  color: _muted,
                  fontSize: 12,
                  height: 1.7,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Please check the audience and details before confirming.',
                style: TextStyle(
                  color: _muted,
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Review'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: _primary,
                foregroundColor: Colors.white,
              ),
              child: const Text('Confirm Send'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    setState(() => _isSending = true);

    // AppState stores circular metadata locally.
    // The message and attachment are not stored by the current model.
    AppState.instance.addCircular(
      CircularRecord(
        title: title,
        audience: audience,
        category: category,
        families: families,
        sentAt: DateTime.now(),
        eventDate: _eventDate,
        attachment: _attachment,
      ),
    );

    if (!mounted) return;

    setState(() {
      _title.clear();
      _message.clear();
      _category = 'Notice';
      _eventDate = null;
      _attachment = null;
      _audience = 0;
      _chosen.clear();
      _isSending = false;
    });

    _showMessage(
      'Circular saved in demo history for $families families.',
    );
  }

  Future<void> _preview() async {
    if (_title.text.trim().isEmpty ||
        _message.text.trim().isEmpty) {
      _showMessage('Enter title and message to preview.');
      return;
    }

    await showDialog<void>(
      context: context,
      builder: (ctx) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          child: Padding(
            padding: const EdgeInsets.all(19),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Circular Preview',
                          style: TextStyle(
                            color: _dark,
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(ctx),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  _categoryBadge(_category),
                  const SizedBox(height: 15),
                  Text(
                    _title.text.trim(),
                    style: const TextStyle(
                      color: _dark,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    _message.text.trim(),
                    style: const TextStyle(
                      color: _muted,
                      fontSize: 13,
                      height: 1.6,
                    ),
                  ),
                  const Divider(height: 25),
                  _previewInfo(
                    Icons.groups_outlined,
                    'Audience',
                    _audienceLabel,
                  ),
                  const SizedBox(height: 10),
                  _previewInfo(
                    Icons.family_restroom_rounded,
                    'Families',
                    '$_families',
                  ),
                  if (_eventDate != null) ...[
                    const SizedBox(height: 10),
                    _previewInfo(
                      Icons.calendar_month_rounded,
                      'Date',
                      AppState.shortDate(_eventDate!),
                    ),
                  ],
                  if (_attachment != null) ...[
                    const SizedBox(height: 10),
                    _previewInfo(
                      Icons.attach_file_rounded,
                      'Attachment',
                      _attachment!,
                    ),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          vertical: 13,
                        ),
                      ),
                      child: const Text('Close Preview'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _previewInfo(
      IconData icon,
      String label,
      String value,
      ) {
    return Row(
      children: [
        Icon(icon, size: 17, color: _primary),
        const SizedBox(width: 8),
        Text(
          '$label: ',
          style: const TextStyle(
            color: _muted,
            fontSize: 11,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: _dark,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final history = AppState.instance.circulars;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F8F6),
      appBar: buildPageAppBar(
        title: 'New Circular',
        subtitle: 'Announcements for parents',
        onBack: widget.onBack,
        actions: [
          IconButton(
            tooltip: 'Preview circular',
            onPressed: _preview,
            icon: const Icon(
              Icons.visibility_outlined,
              color: _primary,
            ),
          ),
          const SizedBox(width: 5),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
              children: [
                // HEADER
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF2F8877),
                        Color(0xFF55AD96),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(21),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Keep Everyone Informed',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 7),
                            Text(
                              'Send important school updates, '
                                  'events and reminders to families.',
                              style: TextStyle(
                                color: Colors.white.withValues(
                                  alpha: 0.88,
                                ),
                                fontSize: 11,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              '${AppState.instance.totalFamilies} families registered',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        height: 65,
                        width: 65,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.17),
                          borderRadius: BorderRadius.circular(19),
                        ),
                        child: const Icon(
                          Icons.campaign_rounded,
                          color: Colors.white,
                          size: 35,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // AUDIENCE
                _sectionTitle(
                  'Send Circular To',
                  'Choose who should receive this message',
                ),

                const SizedBox(height: 11),

                Column(
                  children: [
                    _audienceOption(
                      title: 'Whole School',
                      subtitle:
                      'All ${AppState.instance.totalFamilies} families',
                      icon: Icons.apartment_rounded,
                      selected: _audience == 0,
                      onTap: () {
                        setState(() => _audience = 0);
                      },
                    ),
                    const SizedBox(height: 9),
                    _audienceOption(
                      title: 'Nursery A',
                      subtitle: '${_classFamilies['Nursery A']} families',
                      icon: Icons.child_care_rounded,
                      selected: _audience == 1,
                      onTap: () {
                        setState(() => _audience = 1);
                      },
                    ),
                    const SizedBox(height: 9),
                    _audienceOption(
                      title: 'Choose Classes',
                      subtitle: _chosen.isEmpty
                          ? 'Select multiple classes'
                          : _chosen.join(', '),
                      icon: Icons.groups_rounded,
                      selected: _audience == 2,
                      onTap: _pickClasses,
                      trailing: const Icon(
                        Icons.chevron_right_rounded,
                        color: _muted,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // AUDIENCE SUMMARY
                Container(
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE7F3EE),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.people_alt_rounded,
                        color: _primary,
                        size: 20,
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          '$_families families will receive this circular',
                          style: const TextStyle(
                            color: _dark,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),

                // CATEGORY
                _sectionTitle(
                  'Circular Type',
                  'Select the category of announcement',
                ),

                const SizedBox(height: 11),

                Wrap(
                  spacing: 8,
                  runSpacing: 9,
                  children: [
                    for (final category in _categories)
                      _categoryChip(category),
                  ],
                ),

                if (_category != 'Notice') ...[
                  const SizedBox(height: 14),
                  _dateSelector(),
                ],

                const SizedBox(height: 22),

                // TITLE
                _sectionTitle(
                  'Circular Title',
                  'Give your announcement a clear heading',
                ),

                const SizedBox(height: 11),

                TextField(
                  controller: _title,
                  maxLength: 80,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: _inputDecoration(
                    hint: 'e.g. Dussehra Holiday Announcement',
                    icon: Icons.title_rounded,
                  ),
                ),

                const SizedBox(height: 12),

                // MESSAGE
                _sectionTitle(
                  'Message',
                  'Write the details for parents',
                ),

                const SizedBox(height: 11),

                TextField(
                  controller: _message,
                  maxLines: 5,
                  maxLength: 1000,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: _inputDecoration(
                    hint: 'Write the message for parents...',
                    icon: Icons.edit_note_rounded,
                  ).copyWith(
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 13),

                // ATTACHMENT
                _sectionTitle(
                  'Attachment',
                  'Add a PDF or image if required (optional)',
                ),

                const SizedBox(height: 11),

                if (_attachment == null)
                  InkWell(
                    onTap: _attach,
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                          color: const Color(0xFFDCE8E2),
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Row(
                        children: [
                          Icon(
                            Icons.attach_file_rounded,
                            color: _primary,
                            size: 22,
                          ),
                          SizedBox(width: 11),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Attach PDF / Image',
                                  style: TextStyle(
                                    color: _dark,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'Choose an optional attachment · Demo',
                                  style: TextStyle(
                                    color: _muted,
                                    fontSize: 10,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(
                            Icons.add_circle_outline_rounded,
                            color: _primary,
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: const Color(0xFFE5ECE9),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _attachment!.endsWith('.pdf')
                              ? Icons.picture_as_pdf_rounded
                              : Icons.image_rounded,
                          color: _primary,
                          size: 21,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            _attachment!,
                            style: const TextStyle(
                              color: _dark,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Remove attachment',
                          onPressed: () {
                            setState(() => _attachment = null);
                          },
                          icon: const Icon(
                            Icons.close_rounded,
                            color: Color(0xFFE16B61),
                            size: 19,
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 22),

                // HISTORY
                Row(
                  children: [
                    Expanded(
                      child: _sectionTitle(
                        'Sent Circulars',
                        'Your recent circular history',
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE7F3EE),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '${history.length} sent',
                        style: const TextStyle(
                          color: _primary,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 11),

                if (history.isEmpty)
                  _emptyHistory()
                else
                  for (final circular in history)
                    _historyCard(circular),

                const SizedBox(height: 10),
              ],
            ),
          ),

          // BOTTOM ACTIONS
          Container(
            padding: const EdgeInsets.fromLTRB(16, 11, 16, 13),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 48,
                      child: OutlinedButton.icon(
                        onPressed: _preview,
                        icon: const Icon(
                          Icons.visibility_outlined,
                          size: 17,
                        ),
                        label: const Text(
                          'Preview',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _primary,
                          side: const BorderSide(
                            color: Color(0xFFB9DCD2),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: AppButton(
                      title: _isSending
                          ? 'Sending...'
                          : 'Send to $_families Families',
                      icon: Icons.notifications_active_outlined,
                      onPressed: _isSending ? null : _send,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: _dark,
            fontSize: 15,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: const TextStyle(
            color: _muted,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _audienceOption({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(15),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFFF0F8F5)
                : Colors.white,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: selected
                  ? _primary
                  : const Color(0xFFE6ECE9),
              width: selected ? 1.4 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                height: 42,
                width: 42,
                decoration: BoxDecoration(
                  color: selected
                      ? const Color(0xFFDDF2EC)
                      : const Color(0xFFF1F5F3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: selected ? _primary : _muted,
                  size: 21,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: _dark,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: _muted,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              trailing ??
                  Icon(
                    selected
                        ? Icons.radio_button_checked_rounded
                        : Icons.radio_button_off_rounded,
                    color: selected ? _primary : _muted,
                    size: 19,
                  ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(String category) {
    final selected = _category == category;
    final color = _categoryColors[category]!;

    return ChoiceChip(
      avatar: Icon(
        _categoryIcons[category],
        size: 15,
        color: selected ? color : _muted,
      ),
      label: Text(category),
      selected: selected,
      showCheckmark: false,
      selectedColor: color.withValues(alpha: 0.13),
      backgroundColor: Colors.white,
      side: BorderSide(
        color: selected
            ? color.withValues(alpha: 0.55)
            : const Color(0xFFE5ECE9),
      ),
      labelStyle: TextStyle(
        color: selected ? color : _dark,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      onSelected: (_) {
        setState(() {
          _category = category;
          if (category == 'Notice') _eventDate = null;
        });
      },
    );
  }

  Widget _categoryBadge(String category) {
    final color = _categoryColors[category]!;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _categoryIcons[category],
            size: 14,
            color: color,
          ),
          const SizedBox(width: 6),
          Text(
            category,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateSelector() {
    return InkWell(
      onTap: _pickDate,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: const Color(0xFFE5ECE9),
          ),
        ),
        child: Row(
          children: [
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: const Color(0xFFE7F3EE),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(
                Icons.calendar_month_rounded,
                color: _primary,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _eventDate == null
                        ? 'Select $_category Date'
                        : '$_category Date',
                    style: const TextStyle(
                      color: _dark,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _eventDate == null
                        ? 'Choose a date for the school calendar'
                        : AppState.dateLabel(_eventDate!),
                    style: const TextStyle(
                      color: _muted,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: _muted,
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecoration({
    required String hint,
    required IconData icon,
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(
        color: Color(0xFFA1AAA6),
        fontSize: 11,
      ),
      prefixIcon: Icon(
        icon,
        color: _primary,
        size: 19,
      ),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.all(14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: Color(0xFFE5ECE9),
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: Color(0xFFE5ECE9),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(
          color: _primary,
          width: 1.4,
        ),
      ),
    );
  }

  Widget _historyCard(CircularRecord circular) {
    final color =
        _categoryColors[circular.category] ?? _primary;
    final icon =
        _categoryIcons[circular.category] ?? Icons.description;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: const Color(0xFFE7EEEA),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 43,
            width: 43,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.11),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: color,
              size: 21,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  circular.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _dark,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '${circular.category} · ${circular.audience}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 10,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '${circular.families} families'
                      '${circular.eventDate == null ? '' : ' · ${AppState.shortDate(circular.eventDate!)}'}',
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 10,
                  ),
                ),
                if (circular.attachment != null) ...[
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      const Icon(
                        Icons.attach_file_rounded,
                        size: 12,
                        color: _primary,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        circular.attachment!,
                        style: const TextStyle(
                          color: _primary,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: _primary,
                size: 17,
              ),
              const SizedBox(height: 7),
              Text(
                AppState.timeLabel(circular.sentAt),
                style: const TextStyle(
                  color: _muted,
                  fontSize: 9,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _emptyHistory() {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 25,
        horizontal: 15,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFE7EEEA),
        ),
      ),
      child: const Column(
        children: [
          Icon(
            Icons.mark_email_unread_outlined,
            size: 34,
            color: Color(0xFF9BAAA4),
          ),
          SizedBox(height: 9),
          Text(
            'No circulars yet',
            style: TextStyle(
              color: _dark,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 5),
          Text(
            'Your sent circulars will appear here.',
            style: TextStyle(
              color: _muted,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}
